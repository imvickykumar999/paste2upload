# paste2upload
Paste Image from clipboard to upload file in flask framework.
